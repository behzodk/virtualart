from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import render
from django.contrib.auth.models import User
from main_app.models import *
from django.db.models.functions import TruncMonth
from django.db.models import Count
from django.http import JsonResponse

def is_admin(user):
    return user.is_authenticated and user.is_superuser

@user_passes_test(is_admin)
def index(request):
   
    user = request.user
    clips = Clip.objects.all()
    folders = Folder.objects.all()
    user_count = User.objects.count()
    comments = Comment.objects.all()
    user_valid = Profile.objects.filter(email_confirmed=True)
    context = {'user_count': user_count, 'user': user, 'clips': clips, 'comments': comments, 'user_valid': user_valid, 'folders': folders}
    return render(request, 'adminpanel/index.html', context)

def folderChart(request):
    user_counts_per_month = (
        Clip.objects
        .annotate(month=TruncMonth('created_at'))
        .values('month')
        .annotate(count=Count('id'))
        .order_by('month')
    )
    months = [user_count['month'].strftime("%b") for user_count in user_counts_per_month]
    user_counts = [user_count['count'] for user_count in user_counts_per_month]
    data = {"months": months, "user_counts": user_counts}
    return JsonResponse(data)

def userChartResponse(request):
    user_counts_per_month = (
        User.objects
        .annotate(month=TruncMonth('date_joined'))
        .values('month')
        .annotate(count=Count('id'))
        .order_by('month')
    )
    months = [user_count['month'].strftime("%b") for user_count in user_counts_per_month]
    user_counts = [user_count['count'] for user_count in user_counts_per_month]
    data = {"months": months, "user_counts": user_counts}
    return JsonResponse(data)