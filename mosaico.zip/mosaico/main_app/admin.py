from django.contrib import admin
from .models import Folder, Clip, Comment, Profile
# Register your models here.

admin.site.register(Folder)
admin.site.register(Clip)
admin.site.register(Comment)
admin.site.register(Profile)