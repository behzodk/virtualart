from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='home'),
    path('clip', clip_detail, name='clip_detail'),
    path('like/<int:pk>', LikeView, name='like_clip'),
    path('dislike/<int:pk>', DislikeView, name='dislike_clip'),
    path('login', login_view, name='login'),
    path('signup', signup, name='register'),
    path('logout', logout_view, name='logout'),
    path('api/usernames/', get_usernames, name='api_usernames'),
    path('api/email/', get_email, name='api_email'),
    path('profile/', profile, name='profile'),
    path('success/', success, name='success'),
    path('ivalid-link/', ivalid_link, name='ivalid-link'),
    path('activate/<str:token>', activate, name='activate'),
    path('create', createClip, name='createClip')
]