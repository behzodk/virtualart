from django.shortcuts import render, get_object_or_404, redirect
from .models import *
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import redirect
from django.contrib import messages
from django.http import JsonResponse
from .utils import *
from django.template.loader import render_to_string
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect
from datetime import date

# Create your views here.
def index(request):
    clips = Clip.objects.all()
    return render(request, 'gallery/index.html', context={"clips": clips})

def success(request):
    return render(request, 'gallery/success.html')

def ivalid_link(request):
    return render(request, 'gallery/invalid_link.html')

def clip_detail(request):
    slug = request.GET.get('c')
    clip = get_object_or_404(Clip, slug=slug)
    if request.method == 'POST':
        if not request.user.is_authenticated:
            return redirect('login')
        text = request.POST.get('text')
        comment = Comment.objects.create(
            clip=clip,
            user=request.user,
            text=text
        )
        comment.save()
        return HttpResponseRedirect(request.path_info + '?c=' + slug)
    comment = clip.comments.all()
    comment = reversed(comment)
    count_likes = clip.likes.count()
    count_dislikes = clip.dislikes.count()
    liked = False
    disliked = False
    if clip.likes.filter(id=request.user.id).exists():
        liked=False
    else:
        liked=True
    if clip.dislikes.filter(id=request.user.id).exists():
        disliked=False
    else:
        disliked=True
    return render(request, 'gallery/clip_detail.html', {'clip': clip, 'comments': comment, 'count_likes': str(count_likes),'count_dislikes': str(count_dislikes),'liked': liked, 'disliked': disliked})

def LikeView(request, pk):
    clip = get_object_or_404(Clip, id=request.POST.get('clip_id'))
    if clip.likes.filter(id=request.user.id).exists():
        clip.likes.remove(request.user)
    else:
        clip.likes.add(request.user)
    if clip.dislikes.filter(id=request.user.id).exists():
        clip.dislikes.remove(request.user)
    return redirect(f"/clip?c={clip.slug}")

def DislikeView(request, pk):
    clip = get_object_or_404(Clip, id=request.POST.get('clip_id'))
    if clip.dislikes.filter(id=request.user.id).exists():
        clip.dislikes.remove(request.user)
    else:
        clip.dislikes.add(request.user)
    if clip.likes.filter(id=request.user.id).exists():
        clip.likes.remove(request.user)
    return redirect(f"/clip?c={clip.slug}")

def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            profile = user.profile
            if profile.email_confirmed:
                login(request, user)
                return redirect('home')
            else:
                messages.error(request, f'Your email is not confirmed. Please check your inbox for a confirmation email. EMAIL: {user.email}')
        else:
            messages.error(request, 'No user found with these credentials.')

    return render(request, 'gallery/login.html')

def signup(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        firstName = request.POST.get('firstName')
        lastName = request.POST.get('lastName')
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        dob = request.POST.get('dob')
        user = User.objects.create_user(
            first_name=firstName, 
            username=username, 
            last_name=lastName, 
            email=email, 
            password=password
        )
        user.save()
        auth_token = generate_random_slug(length=25)
        profile = Profile.objects.create(user=user, auth_token=auth_token, date_of_birth=dob)
        profile.save()
        mail_subject = 'Activate your user account.'
        message = render_to_string('gallery/activate.html', {
            'user': user.username,
            'domain': get_current_site(request).domain,
            'token': auth_token,
            'protocol': 'https' if request.is_secure() else 'http'
        })

        mail = EmailMessage(mail_subject, message, to=[email])
        mail.send()
        return redirect('success')
    return render(request, 'gallery/signup.html')

def logout_view(request):
    if request.user.is_authenticated:
        logout(request)
    return redirect('home')

def get_usernames(request):
    usernames = list(User.objects.values_list('username', flat=True))
    usernames.extend(premium)
    return JsonResponse(usernames, safe=False)

def get_email(request):
    emailList = list(User.objects.values_list('email', flat=True))
    return JsonResponse(emailList, safe=False)

def profile(request):
    clips = Clip.objects.filter(user=request.user)
    dob = request.user.profile.date_of_birth
    today = date.today()
    next_birthday = date(today.year, dob.month, dob.day)

    if today > next_birthday:
        next_birthday = date(today.year + 1, dob.month, dob.day)

    days_until_birthday = (next_birthday - today).days
    return render(request, 'gallery/profile.html', {'user': request.user, 'clips': clips, 'dob': days_until_birthday})

def activate(request, token):
    try:
        user = Profile.objects.filter(auth_token=token).first()
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None:
        if user.email_confirmed:
            return redirect('ivalid-link')
        else:
            user.email_confirmed = True
            user.save()

            messages.success(request, 'Thank you for your email confirmation. Now you can login your account.')
            return redirect('login')
    else:
        messages.error(request, 'Activation link is invalid!')
    
    return redirect('homepage')

def createClip(request):
    return render(request, 'gallery/create.html')