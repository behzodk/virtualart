from django.db import models
from django.contrib.auth.models import User
import uuid
from django.db.models.signals import pre_save
from django.dispatch import receiver
from .utils import generate_random_slug

# Create your models here.
class Folder(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class Clip(models.Model):
    folder = models.ForeignKey(Folder, related_name='clips', on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    title = models.CharField(max_length=255)
    slug = models.SlugField(null=True, blank=True, unique=True)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='clips/')
    created_at = models.DateTimeField(auto_now_add=True)
    likes = models.ManyToManyField(User, related_name='clips_images', blank=True, null=True)
    dislikes = models.ManyToManyField(User, related_name='clips_images_dis', blank=True, null=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            while True:
                unique_id = generate_unique_slug()
                if not Clip.objects.filter(slug=unique_id).exists():
                    self.slug = unique_id
                    break
        super(Clip, self).save(*args, **kwargs)

    def __str__(self):
        return self.title

def generate_unique_slug():
    slug = generate_random_slug()
    while Clip.objects.filter(slug=slug).exists():
        slug = generate_random_slug()
    return slug

class Comment(models.Model):
    clip = models.ForeignKey(Clip, related_name='comments', on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Comment by {self.user.username} on {self.clip.title}'
    
class Profile(models.Model):
    user = models.OneToOneField(User, null=True, on_delete=models.CASCADE)
    bio = models.TextField(null=True, blank=True)
    image = models.ImageField(upload_to='profile_pics/', default='img.jpg')
    email_confirmed = models.BooleanField(default=False)
    auth_token = models.CharField(max_length=100, null=True, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if not self.auth_token:
            while True:
                token = generate_random_slug(length=25)
                if not Profile.objects.filter(auth_token=token).exists():
                    self.auth_token = token
                    break
        super(Profile, self).save(*args, **kwargs)

    def __str__(self):
        return str(self.user)